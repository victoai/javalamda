package ch14.practice;

public class 문제1 {

	
	//문제
	//PracticeLib 클래스를 만드시오
	//1.1 : 별을 출력하는 매서드를 만드시오
	//1.2 : 문자를 입력받아 해당 문자를 출력하는 매서드를 만드시오
	//1.3 : 실행할 코드를 입력 받아 코드를 실행해주는 매서드를 만드시오
	
	//1.3  을 위해서  Runnable인터페이스를 사용하시오    
	/*
	 *  interface Runnable {
	 *        void run() ;
	 *   }	  
	 */
	
	//1.4  practiceJW.jar 라이브러리로 만드시오 , 자신의 이니셜
	//1.5  다른 사람이 만든 라이브러리를 추가하고  라이브러리의 매서드3개를 사용하는 클래스를 작성하고 실행하시오
	
	
	public static void main(String[] args) {
		 
		
		

	}

}
