package annotation.sample2;


public enum LimitType {
	MAX , MIN
}
